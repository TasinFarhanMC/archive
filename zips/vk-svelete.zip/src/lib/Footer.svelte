<footer class="bg-gray-800 text-white py-3 text-sm">
  <div class="w-full max-w-6xl mx-auto px-4 flex justify-between items-center">
    <!-- Left: Copyright -->
    <p class="text-gray-400">
      &copy; {new Date().getFullYear()} Virtual Kushtia. All rights reserved. Email:
      <a href="mailto:tasinfarhan1016@gmail.com">tasinfarhan1016@gmail.com</a>
    </p>
  </div>
</footer>
