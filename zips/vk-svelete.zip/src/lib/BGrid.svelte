<script lang="ts">
  let { buttons }: { buttons: any[] } = $props();

  function navigate(url: string) {
    window.location.href = url;
  }
</script>

<section id="buttons-section" class="content">
  <div class="grid-container">
    {#each buttons as button}
      <button onclick={() => navigate(button.url)}>
        {#if button.icon}
          <img src={`/icon/${button.icon}`} alt={button.label} class="icon" />
        {/if}
        <span class="label">{button.label}</span>
      </button>
    {/each}
  </div>
</section>
