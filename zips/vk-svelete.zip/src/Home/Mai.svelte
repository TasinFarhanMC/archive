<script>
  import { fly } from "svelte/transition";

  let images = Array.from({ length: 10 }, (_, i) => `/bckgrd/${i}.jpeg`);
  let currentIndex = 0;

  function nextImage() {
    currentIndex = (currentIndex + 1) % images.length;
  }

  setInterval(nextImage, 3000);

  // List of buttons with icon paths and names
  let buttons = [
    { icon: "/icon/icon1.svg", name: "আমাদের কুষ্টিয়া" },
    { icon: "/icon/icon2.svg", name: "ঐতিহ্য ও ভাষা" },
    { icon: "/icon/icon3.svg", name: "দর্শনীয়  স্থান ও স্থাপনা" },
    { icon: "/icon/icon6.svg", name: "ইতিহাস" },
    { icon: "/icon/icon7.svg", name: "খবর" },
    { icon: "/icon/icon5.svg", name: "বই" },
  ];
</script>

<div class="top-bar">
  <button style="margin-right: auto; background: inherit;">
    <img src="/icon/menu.svg" alt="Menu" class="icon" />
  </button>

  <button
    style="background: inherit; display: flex; align-items: center;"
    on:click={() => {
      window.location.href = "https://maps.app.goo.gl/tQpg4iSoscFqc1WY6";
    }}
  >
    <img src="/icon/map.svg" alt="Map" class="icon" style="scale: 50%;" />
    <span style="font-size: 1.5vw;">Kushtia</span>
  </button>

  <button style="margin-left: auto; background: inherit;">
    <img src="/icon/profile.svg" alt="Profile" class="icon" />
  </button>
</div>

<div class="search-bar">
  <div class="search-container">
    <img src="/icon/search.svg" alt="Search Icon" class="search-icon" />
    <input type="text" placeholder="Search..." />
  </div>
</div>

<!-- Image Slider -->
<div class="slider">
  {#each images as image, i (image)}
    <img
      src={image}
      alt="Sliding image"
      class:visible={i === currentIndex}
      transition:fly={{ x: 300, duration: 500 }}
    />
  {/each}

  <!-- Progress Bar -->
  <div class="progress-bar">
    <div
      class="progress"
      style="width: {((currentIndex + 1) / images.length) * 100}%"
    ></div>
  </div>
</div>

<!-- Circular Icon Buttons with Labels Below Slider -->
<div class="icon-buttons">
  {#each buttons as btn}
    <div class="icon-button-item">
      <button class="circular-icon">
        <img src={btn.icon} alt={btn.name} />
      </button>
      <div class="icon-label">{btn.name}</div>
    </div>
  {/each}
</div>

<style lang="scss">
  .top-bar {
    position: absolute;
    display: flex;
    width: 100%;
    height: 8%;
    background-color: lighten(#203040, 10%);
  }

  .search-bar {
    position: absolute;
    top: 8vh;
    width: 100vw;
    display: flex;
    justify-content: center;
    background: linear-gradient(lighten(#203040, 10%), #203040);
    padding: 1vh 0;
  }

  .search-container {
    display: flex;
    align-items: center;
    position: relative;
    width: 50vw;
    background: #203040;
    border-radius: 1vw;
    padding: 0.5vh;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
  }

  .search-bar input {
    flex: 1;
    padding: 1vh 1vw;
    padding-left: 3vw;
    font-size: 1.2vw;
    color: white;
    background-color: transparent;
    border: none;
    border-radius: 1vw;
    outline: none;
  }

  .search-icon {
    position: absolute;
    left: 1vw;
    height: 2vh;
    width: 2vh;
    object-fit: contain;
    transition: transform 0.2s ease;
    opacity: 0.8;
  }

  .search-container:hover .search-icon {
    transform: scale(1.1);
    opacity: 1;
  }

  button {
    border: none;
    cursor: pointer;
    transition:
      background-color 0.3s ease,
      transform 0.2s ease;
  }

  button:hover {
    background-color: rgba(255, 255, 255, 0.1);
    transform: scale(1.05);
  }

  button:focus {
    outline: none;
  }

  .icon {
    height: 6vh;
    object-fit: cover;
    transition: transform 0.2s ease;
  }

  button img[style="scale: 50%"] {
    transform: scale(0.5);
  }

  button:hover .icon {
    transform: scale(1.1);
  }

  .slider {
    position: absolute;
    top: 25vh;
    left: 50%;
    transform: translateX(-50%);
    width: 50vw;
    height: 50vh;
    overflow: hidden;
    border-radius: 1vw;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
  }

  .slider img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0;
    transition: opacity 0.5s ease-in-out;
  }

  .slider img.visible {
    opacity: 1;
  }

  .progress-bar {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background-color: rgba(0, 0, 0, 0.3);
  }

  .progress {
    height: 100%;
    background-color: #00bcd4;
    transition: width 0.5s ease-in-out;
  }

  /* Styles for Circular Icon Buttons and Labels */
  .icon-buttons {
    position: absolute;
    top: 83vh; /* Adjust based on layout */
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    justify-content: center;
    gap: 4vw;
  }

  .icon-button-item {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .circular-icon {
    width: 12vh; /* Increased size */
    height: 12vh; /* Increased size */
    border-radius: 50%;
    background: linear-gradient(
      45deg,
      lighten(#203040, 30%),
      lighten(#203040, 10%)
    ); /* Gradient matching #203040 */
    display: flex;
    justify-content: center;
    align-items: center;
    border: none;
    outline: none;
    transition: transform 0.2s ease;
  }

  .circular-icon:hover {
    transform: scale(1.1);
  }

  .circular-icon img {
    width: 50%;
    height: 50%;
    object-fit: contain;
  }

  .icon-label {
    margin-top: 1vh;
    font-size: 2vh;
    color: white;
    text-align: center;
  }
</style>
