<script>
  import { fly } from "svelte/transition";
  import Section from "./Section.svelte";

  // Image slider
  let images = Array.from({ length: 10 }, (_, i) => `/bckgrd/${i}.jpeg`);
  let currentIndex = 0;
  function nextImage() {
    currentIndex = (currentIndex + 1) % images.length;
  }
  setInterval(nextImage, 3000);

  let buttons = [
    {
      icon: "/icon/amarkushtia.jpg",
      name: "আমাদের কুষ্টিয়া",
      url: "/Kushtia.pdf",
    },
    { icon: "/icon/culture.jpg", name: "ঐতিহ্য ও ভাষা", url: "#/people" },
    { icon: "/icon/spot.jpeg", name: "দর্শনীয়  স্থান ও স্থাপনা", url: "" },
    { icon: "/icon/history.jpeg", name: "ইতিহাস", url: "" },
    { icon: "/icon/news.jpeg", name: "খবর", url: "" },
    { icon: "/icon/book.jpeg", name: "বই", url: "" },
  ];

  // Govt section buttons data
  let govtButtons = [
    {
      icon: "/icon/problem.jpeg",
      name: "সমস্যা জানান",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/ec.png",
      name: "নির্বাচন কমিশন",
      url: "https://example.com/2",
    },
    {
      icon: "/icon/land.jpeg",
      name: "ভূমি মন্ত্রণালয়",
      url: "https://example.com/3",
    },
    { icon: "/icon/tax.jpg", name: "কর প্রদান", url: "https://example.com/3" },
    {
      icon: "/icon/pass.jpeg",
      name: "পাসপোর্ট অফিস",
      url: "https://example.com/3",
    },
    {
      icon: "/icon/elec.jpeg",
      name: "পল্লী বিদ্যুৎ",
      url: "https://example.com/3",
    },
    {
      icon: "/icon/land.jpeg",
      name: "জেলা প্রশাসন",
      url: "https://example.com/3",
    },
    {
      icon: "/icon/post.jpeg",
      name: "পোস্ট অফিস",
      url: "https://example.com/3",
    },
    { icon: "/icon/cort.jpeg", name: "আদালত", url: "https://example.com/3" },
    { icon: "/icon/police.jpeg", name: "থানা", url: "https://example.com/3" },
    {
      icon: "/icon/land.jpeg",
      name: "জেলা প্রশাসন",
      url: "https://example.com/3",
    },
    {
      icon: "/icon/citi.jpeg",
      name: "নাগরিক অনুসন্ধান",
      url: "https://example.com/3",
    },
  ];

  let emerButtons = [
    {
      icon: "/icon/hotline.jpeg",
      name: "জরুরী হট লাইন",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/blood.jpg",
      name: "ব্লাড ডোনার",
      url: "https://example.com/2",
    },
    { icon: "/icon/police.jpeg", name: "পুলিশ", url: "https://example.com/3" },
    {
      icon: "/icon/amb.jpeg",
      name: "অ্যাম্বুলেন্স",
      url: "https://example.com/1",
    },
    { icon: "/icon/hosp.jpeg", name: "হাসপাতাল", url: "https://example.com/2" },
    {
      icon: "/icon/doctor.jpeg",
      name: "ডাক্তার",
      url: "https://example.com/3",
    },
    { icon: "/icon/law.jpeg", name: "আইনজীবী", url: "https://example.com/1" },
  ];

  let helButtons = [
    {
      icon: "/icon/blood.jpg",
      name: "ব্লাড ডোনার",
      url: "https://example.com/2",
    },
    {
      icon: "/icon/amb.jpeg",
      name: "অ্যাম্বুলেন্স",
      url: "https://example.com/1",
    },
    { icon: "/icon/hosp.jpeg", name: "হাসপাতাল", url: "https://example.com/2" },
    {
      icon: "/icon/doctor.jpeg",
      name: "ডাক্তার",
      url: "https://example.com/3",
    },
  ];

  let lawButtons = [
    { icon: "/icon/police.jpeg", name: "পুলিশ", url: "https://example.com/1" },
    {
      icon: "/icon/cyber.jpeg",
      name: "সাইবার সিকিউরিটি",
      url: "https://example.com/2",
    },
    {
      icon: "/icon/fire.jpeg",
      name: "ফায়ার সার্ভিস",
      url: "https://example.com/2",
    },
    {
      icon: "/icon/journal.jpeg",
      name: "সাংবাদিক",
      url: "https://example.com/2",
    },
  ];

  let citiButtons = [
    {
      icon: "/icon/govt1.svg",
      name: "নাগরিক অনুসন্ধান",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt2.svg",
      name: "অভিযোগ পোর্টাল",
      url: "https://example.com/2",
    },
  ];

  let transButtons = [
    { icon: "/icon/bus.jpeg", name: "বাস টিকেট", url: "https://example.com/1" },
    {
      icon: "/icon/govt1.svg",
      name: "কার রেন্ট",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "ট্রেন টিকেট",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "বিমান টিকেট",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "কুরিয়ার সার্ভিস",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "ট্রাভেল এজেন্সি",
      url: "https://example.com/1",
    },
  ];

  let entertainButtons = [
    { icon: "/icon/govt1.svg", name: "দর্শনীয় স্থান", url: "/#people" },
    {
      icon: "/icon/govt1.svg",
      name: "পার্ক ও খেলার মাঠ",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "ধর্ম উপাসনালয়",
      url: "https://example.com/1",
    },
    { icon: "/icon/govt1.svg", name: "সংগঠন", url: "https://example.com/1" },
    {
      icon: "/icon/govt1.svg",
      name: "গুরুত্বপূর্ণ স্থান",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "মুভি থিয়েটার",
      url: "https://example.com/1",
    },
    { icon: "/icon/govt1.svg", name: "Gym", url: "https://example.com/1" },
  ];

  let hotelButtons = [
    { icon: "/icon/govt1.svg", name: "শপিং মল", url: "https://example.com/1" },
    { icon: "/icon/govt2.svg", name: "হোটেল", url: "https://example.com/2" },
    {
      icon: "/icon/govt2.svg",
      name: "রেস্টুরেন্ট",
      url: "https://example.com/2",
    },
    { icon: "/icon/govt2.svg", name: "ক্যাফে", url: "https://example.com/2" },
  ];

  let eduButtons = [
    {
      icon: "/icon/govt1.svg",
      name: "প্রাথমিক-মাধ্যমিক স্কুল",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "কলেজ ইউনিভার্সিটি",
      url: "https://example.com/1",
    },
    { icon: "/icon/govt1.svg", name: "কারিগরি", url: "https://example.com/1" },
    { icon: "/icon/govt1.svg", name: "মাদ্রাসা", url: "https://example.com/1" },
    {
      icon: "/icon/govt1.svg",
      name: "ট্রেডিং ইনস্টিটিউট",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "কোচিং সেন্টার",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "আইটি সার্ভিস",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "আইটি ফার্ম",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt1.svg",
      name: "মোবাইল ইলেকট্রনিক্স",
      url: "https://example.com/1",
    },
  ];

  let labourButtons = [
    {
      icon: "/icon/govt1.svg",
      name: "Electritian",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt2.svg",
      name: "AC Mechanic",
      url: "https://example.com/2",
    },
    { icon: "/icon/govt3.svg", name: "Plumber", url: "https://example.com/3" },
    { icon: "/icon/govt3.svg", name: "Labour", url: "https://example.com/3" },
  ];

  let jobButtons = [
    { icon: "/icon/govt1.svg", name: "", url: "https://example.com/1" },
  ];
  let nearButtons = [
    {
      icon: "/icon/govt1.svg",
      name: "এটিএম ফিলিং স্টেশন",
      url: "https://example.com/1",
    },
    {
      icon: "/icon/govt2.svg",
      name: "হাসপাতাল থানা",
      url: "https://example.com/2",
    },
    {
      icon: "/icon/govt3.svg",
      name: "পার্কিং বাস স্ট্যান্ড",
      url: "https://example.com/3",
    },
    { icon: "/icon/govt1.svg", name: "ব্যাংক", url: "https://example.com/1" },
    {
      icon: "/icon/govt1.svg",
      name: "পার্ক ও খেলার মাঠ",
      url: "https://example.com/1",
    },
  ];
</script>

<!-- Govt Section using the SectionButtons component -->
<Section position="105%" header="সরকারি সেবা" buttons={govtButtons} />
<Section position="140%" header="জরুরী সেবা" buttons={emerButtons} />
<Section position="175%" header="স্বাস্থ্য সেবা" buttons={helButtons} />
<Section position="210%" header="আইন-শৃঙ্খলা " buttons={lawButtons} />
<Section position="245%" header="নাগরিক সেবা" buttons={citiButtons} />
<Section position="280%" header="পরিবহন ও টিকিট" buttons={transButtons} />
<Section position="315%" header="বিনোদন ও আনন্দ" buttons={entertainButtons} />
<Section position="350%" header="হোটেল ও রেস্টুরেন্ট" buttons={hotelButtons} />
<Section position="385%" header="শিক্ষা ও প্রশিক্ষণ" buttons={eduButtons} />
<Section position="420%" header="মিস্ত্রি বা শ্রমিক" buttons={labourButtons} />
<Section position="455%" header="চাকরি বা টিউশন" buttons={jobButtons} />
<Section position="490%" header="নিকটবর্তী সেবা" buttons={nearButtons} />

<!-- Top Bar -->
<div class="top-bar">
  <button style="margin-right: auto; background: inherit;">
    <img src="/icon/menu.svg" alt="Menu" class="icon" />
  </button>
  <button
    style="background: inherit; display: flex; align-items: center;"
    on:click={() => {
      window.location.href = "https://maps.app.goo.gl/tQpg4iSoscFqc1WY6";
    }}
  >
    <img src="/icon/map.svg" alt="Map" class="icon" style="scale: 50%;" />
    <span style="font-size: 1.5vw;">Kushtia</span>
  </button>
  <button style="margin-left: auto; background: inherit;">
    <img src="/icon/profile.svg" alt="Profile" class="icon" />
  </button>
</div>

<!-- Search Bar -->
<div class="search-bar">
  <div class="search-container">
    <img src="/icon/search.svg" alt="Search Icon" class="search-icon" />
    <input type="text" placeholder="Search..." />
  </div>
</div>

<!-- Image Slider -->
<div class="slider">
  {#each images as image, i (image)}
    <img
      src={image}
      alt="Sliding image"
      class:visible={i === currentIndex}
      transition:fly={{ x: 300, duration: 500 }}
    />
  {/each}
  <!-- Progress Bar -->
  <div class="progress-bar">
    <div
      class="progress"
      style="width: {((currentIndex + 1) / images.length) * 100}%"
    ></div>
  </div>
</div>

<!-- Main Circular Icon Buttons -->
<div class="icon-buttons main-buttons">
  {#each buttons as btn}
    <div class="icon-button-item">
      <button
        class="circular-icon"
        on:click={() => (window.location.href = btn.url)}
      >
        <img src={btn.icon} alt={btn.name} />
      </button>
      <div class="icon-label">{btn.name}</div>
    </div>
  {/each}
</div>

<style lang="scss">
  .top-bar {
    position: absolute;
    display: flex;
    width: 100%;
    height: 8%;
    background-color: lighten(#203040, 10%);
  }

  .search-bar {
    position: absolute;
    top: 8vh;
    width: 100vw;
    display: flex;
    justify-content: center;
    background: linear-gradient(lighten(#203040, 10%), #203040);
    padding: 1vh 0;
  }

  .search-container {
    display: flex;
    align-items: center;
    position: relative;
    width: 50vw;
    background: #203040;
    border-radius: 1vw;
    padding: 0.5vh;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
  }

  .search-bar input {
    flex: 1;
    padding: 1vh 1vw;
    padding-left: 3vw;
    font-size: 1.2vw;
    color: white;
    background-color: transparent;
    border: none;
    border-radius: 1vw;
    outline: none;
  }

  .search-icon {
    position: absolute;
    left: 1vw;
    height: 2vh;
    width: 2vh;
    object-fit: contain;
    transition: transform 0.2s ease;
    opacity: 0.8;
  }

  .search-container:hover .search-icon {
    transform: scale(1.1);
    opacity: 1;
  }

  button {
    border: none;
    cursor: pointer;
    transition:
      background-color 0.3s ease,
      transform 0.2s ease;
  }

  button:hover {
    background-color: rgba(255, 255, 255, 0.1);
    transform: scale(1.05);
  }

  button:focus {
    outline: none;
  }

  .icon {
    height: 6vh;
    object-fit: cover;
    transition: transform 0.2s ease;
  }

  button img[style="scale: 50%"] {
    transform: scale(0.5);
  }

  button:hover .icon {
    transform: scale(1.1);
  }

  .slider {
    position: absolute;
    top: 25vh;
    left: 50%;
    transform: translateX(-50%);
    width: 50vw;
    height: 50vh;
    overflow: hidden;
    border-radius: 1vw;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
  }

  .slider img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0;
    transition: opacity 0.5s ease-in-out;
  }

  .slider img.visible {
    opacity: 1;
  }

  .progress-bar {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background-color: rgba(0, 0, 0, 0.3);
  }

  .progress {
    height: 100%;
    background-color: #00bcd4;
    transition: width 0.5s ease-in-out;
  }

  /* Styles for Main Icon Buttons */
  .icon-buttons {
    display: flex;
    gap: 4vw;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
  }

  .main-buttons {
    top: 83vh;
  }

  .icon-button-item {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .circular-icon {
    width: 12vh;
    height: 12vh;
    border-radius: 50%;
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
    border: none;
    outline: none;
    transition: transform 0.2s ease;
  }

  .circular-icon:hover {
    transform: scale(1.1);
  }

  .circular-icon img {
    width: 80%;
    height: 80%;
    object-fit: contain;
  }

  .icon-label {
    margin-top: 1vh;
    font-size: 2vh;
    color: white;
    text-align: center;
  }
</style>
