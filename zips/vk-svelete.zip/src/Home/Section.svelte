<script>
  let { position, header, buttons = [] } = $props();
</script>

<div class="section" style="top: {position};">
  {#if header}
    <h2 class="section-header">{header}</h2>
  {/if}
  <div class="box-buttons">
    {#each buttons as btn}
      <div class="icon-button-item">
        <button
          class="rect-icon"
          onclick={() => (window.location.href = btn.url)}
        >
          <img src={btn.icon} alt={btn.name} />
        </button>
        <div class="icon-label">{btn.name}</div>
      </div>
    {/each}
  </div>
</div>

<style lang="scss">
  .section {
    position: absolute;
    left: 0;
    width: 100%;
  }

  .section-header {
    display: inline-block; /* Shrink to fit the text */
    font-size: 6vh;
    color: #ffd;
    margin-bottom: 2vh;
    padding: 1vh 5vw; /* Adds about 5% extra width on each side */
    text-align: left;
    background-color: rgba(16, 24, 32, 0.8); /* Semi-transparent background */
    border-radius: 3vh; /* Rounded corners */
  }

  .box-buttons {
    display: flex;
    justify-content: flex-start; /* Items start from the left */
    gap: 2vw;
    padding-left: 2vw;
  }

  .icon-button-item {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .rect-icon {
    width: 8vh;
    height: 8vh;
    border-radius: 2vh; /* Minimal rounding for a rectangular look */
    background-color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    border: none;
    outline: none;
    transition: transform 0.2s ease;
  }

  .rect-icon:hover {
    transform: scale(1.1);
  }

  .rect-icon img {
    width: 115%;
    height: 115%;
    object-fit: contain;
  }

  .icon-label {
    margin-top: 1vh;
    font-size: 2vh;
    color: white;
    text-align: center;
  }
</style>
