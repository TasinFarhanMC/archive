<script>
  import Footer from "./lib/Footer.svelte";

  const people = [
    {
      name: "Rabindranath Tagore",
      img: "public/rabindranath.webp",
      link: "https://en.wikipedia.org/wiki/Rabindranath_Tagore",
      desc: "Rabindranath Tagore (7 May 1861 – 7 August 1941) was a Bengali polymath who worked as a poet, writer, playwright, composer, philosopher, social reformer, and painter of the Bengal Renaissance. He reshaped Bengali literature and music as well as Indian art with Contextual Modernism in the late 19th and early 20th centuries. He spent a portion of his time in Kushtia. Residing in his Kutihi Bari in Shilaidah",
    },
    {
      name: "Lalon Shah",
      img: "public/lalon.webp",
      link: "https://en.wikipedia.org/wiki/Lalon",
      desc: "Lalon (died 17 October 1890) also known as Lalon Shah, Lalon Fakir, Shahji, was a Bengali spiritual leader, philosopher, mystic poet and social reformer. Regarded as an icon of Bengali especially Kushtia culture, he inspired and influenced many philosophers, poets and social thinkers including Rabindranath Tagore, Kazi Nazrul Islam and Allen Ginsberg. Lalon's philosophy of humanity rejects all distinctions of caste, class, and creed and takes stand against theological conflicts and racism. It denies all worldly affairs in search of the soul and embodied the socially transformative role of sub-continental Bhakti and Sufism.",
    },
    {
      name: "Mir Mosharraf Hossain",
      img: "public/mosharraf.webp",
      link: "https://en.wikipedia.org/wiki/Mir_Mosharraf_Hossain",
      desc: "Mir Mosharraf Hossain (13 November 1847–19 December 1911) was a Bengali writer, novelist, playwright, and essayist. He was born in Lahini Para of Kumarkhali Upazilla in Kushtia. He is considered to be the first major writer to emerge from the Shia society of Bengal and one of the finest prose writers in the Bengali language. His magnum opus Bishad Sindhu (Ocean of Sorrow) is a popular classic among the Bengali readership.",
    },
  ];

  function getAverageRGB(img) {
    const canvas = document.createElement("canvas");
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const context = canvas.getContext("2d");
    context.drawImage(img, 0, 0);
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    let r = 0,
      g = 0,
      b = 0;
    const pixelCount = data.length / 4;

    for (let i = 0; i < data.length; i += 4) {
      r += data[i];
      g += data[i + 1];
      b += data[i + 2];
    }

    return {
      r: Math.round(r / pixelCount),
      g: Math.round(g / pixelCount),
      b: Math.round(b / pixelCount),
    };
  }

  function setGlowColor(event) {
    const img = event.target;
    const container = img.closest(".image-container");
    if (!container) return;
    const { r, g, b } = getAverageRGB(img);
    container.style.setProperty("--glow-color", `${r}, ${g}, ${b}`);
  }
</script>

<header class="bg-blue-600 text-white py-4">
  <div class="container mx-auto px-4 text-center">
    <a href="#/" class="home-button">Home</a>
  </div>
</header>

<main class="container mx-auto px-4 py-8">
  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
    {#each people as person}
      <figure class="bg-gray-900 rounded-lg shadow-md p-4 text-center">
        <a href={person.link} target="_blank" class="image-container">
          <img src={person.img} alt={person.name} on:load={setGlowColor} />
        </a>
        <figcaption class="mt-4">
          <a
            href={person.link}
            target="_blank"
            class="block text-xl font-semibold text-blue-400 hover:text-blue-600"
          >
            {person.name}
          </a>
          <p class="mt-2 text-sm text-gray-300">{person.desc}</p>
        </figcaption>
      </figure>
    {/each}
  </div>
  <div class="text-center mt-8">
    <a
      href="https://www.kushtia.gov.bd/en/site/page/QHBK-%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%96%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A4-%E0%A6%AC%E0%A7%8D%E0%A6%AF%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BF%E0%A6%A4%E0%A7%8D%E0%A6%AC"
      target="_blank"
      class="text-2xl text-blue-400 hover:text-blue-600 hover:underline"
    >
      For More
    </a>
  </div>
</main>

<Footer />

<style lang="scss">
  /* Container wrapping the image; overflow is visible to let the glow bleed out */
  .image-container {
    position: relative;
    display: inline-block;
    border-radius: 16px;
    overflow: visible;
    /* Default glow color (in case the image hasn't loaded yet) */
    --glow-color: 0, 190, 255;
  }

  /* The image itself */
  .image-container img {
    display: block;
    width: 100%;
    height: 12rem; /* Tailwind's h-48 equivalent */
    object-fit: cover;
    border-radius: 16px;
    transition:
      transform 0.4s ease,
      box-shadow 0.4s ease;
  }

  /* On hover, the image scales up and uses the computed glow color */
  .image-container:hover img {
    transform: scale(1.1);
    box-shadow: 0 0 35px rgba(var(--glow-color), 0.8);
  }

  /* The pseudo-element creates a blurry glowing radial gradient using the computed average color */
  .image-container::after {
    content: "";
    position: absolute;
    top: -10%;
    left: -10%;
    width: 120%;
    height: 120%;
    background: radial-gradient(
      circle,
      rgba(var(--glow-color), 0.8) 50%,
      transparent 75%
    );
    border-radius: 16px;
    pointer-events: none;
    opacity: 0;
    filter: blur(8px);
    transition: opacity 0.4s ease;
    z-index: -1;
  }

  /* Reveal the glow on hover */
  .image-container:hover::after {
    opacity: 1;
  }

  /* Global link styles */
  a {
    text-decoration: none;
    color: #4fa3d1;
    transition:
      color 0.3s ease,
      text-shadow 0.3s ease,
      transform 0.2s ease;
  }

  /* Underline effect */
  a::after {
    content: "";
    display: block;
    width: 0;
    height: 2px;
    background: currentColor;
    transition: width 0.3s ease-in-out;
  }

  /* Expand underline on hover */
  a:hover::after {
    width: 100%;
  }

  /* Text glow effect on hover */
  a:hover {
    color: #68c8ff;
    text-shadow: 0 0 8px rgba(104, 200, 255, 0.7);
    transform: scale(1.05);
  }

  /* Specific styling for navigation links */
  header a {
    font-size: 1.5rem;
    font-weight: bold;
    color: white;
  }

  /* Home link hover effect */
  header a:hover {
    color: #a3e4ff;
    text-shadow: 0 0 10px rgba(163, 228, 255, 0.9);
  }

  /* Footer link styles */
  footer a {
    color: #8bc6ff;
  }

  footer a:hover {
    color: #ffffff;
    text-shadow: 0 0 12px rgba(255, 255, 255, 0.8);
  }

  /* Improve readability for main content links */
  main a {
    font-weight: 600;
    color: #58a6ff;
  }

  main a:hover {
    color: #82caff;
    text-shadow: 0 0 10px rgba(130, 202, 255, 0.8);
  }
  /* Home Button Styles - Blended with Header Background */
  .home-button {
    display: inline-block;
    font-size: 1.8rem;
    font-weight: bold;
    padding: 10px 20px;
    color: #555577;
    border-radius: 8px;
    transition:
      background 0.3s ease,
      transform 0.3s ease,
      box-shadow 0.3s ease;
    border: none; /* Completely remove any border */
    outline: none; /* Remove any focus outlines */
  }

  .home-button:hover {
    background: rgba(37, 99, 235, 0.4); /* Slightly brighter on hover */
    transform: scale(1.05);
    box-shadow: 0 0 15px rgba(255, 255, 255, 0.2);
  }

  .home-button:active {
    transform: scale(0.95);
  }

  .more-info-link {
    display: inline-block;
    font-size: 1.4rem;
    font-weight: bold;
    padding: 8px 16px;
    border-radius: 8px;
    transition: all 0.3s ease;
  }

  .more-info-link:hover {
    color: #ffffff;
    background: rgba(37, 99, 235, 0.5);
    text-shadow: 0 0 10px rgba(130, 202, 255, 0.8);
    transform: scale(1.05);
  }

  .more-info-link:active {
    transform: scale(0.95);
  }

  figcaption {
    color: lighten(#203040, 60%);
  }
</style>
