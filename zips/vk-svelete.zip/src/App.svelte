<script lang="ts">
  import Router from "svelte-spa-router";
  import Login from "./Login.svelte";
  import Home from "./Home/Main.svelte";
  import People from "./People.svelte";
  import Portal from "./Culture/Portal.svelte";

  const routes = {
    "/": Login,
    "/home": Home,
    "/people": People,
  };
</script>

<Router {routes} />
