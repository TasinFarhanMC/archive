<script lang="ts">
  import "./login.scss";

  function handleLogin(event: Event) {
    event.preventDefault();
    const formData = new FormData(event.target as HTMLFormElement);
    const email = formData.get("email");
    const password = formData.get("password");
    // Replace this alert with your actual login/authentication logic.
    alert(`Invalid Email or Password`);
  }

  function continueAsGuest() {
    // Replace this alert with your guest navigation logic.
    alert("Continuing as guest...");
  }
</script>

<div class="login">
  <h1>Welcome!</h1>
  <h2>The Virtual World of Kushtia</h2>

  <!-- Email & Password Login Form -->
  <form class="login-form" onsubmit={handleLogin}>
    <input type="email" name="email" placeholder="Email" required />
    <input type="password" name="password" placeholder="Password" required />
    <button type="submit">Login</button>
  </form>

  <!-- Continue as Guest Button -->
  <button
    class="guest-btn"
    onclick={() => {
      window.location.href = "#/home";
    }}>Continue as Guest</button
  >
</div>

<div class="wallpaper-div">
  <img src="/wallpaper.jpg" alt="Kushtia Pouroshava" class="wallpaper" />
  <h1>Kushtia Pouroshava</h1>
</div>
