<script>
  let links = [
    { name: "Category 1", url: "https://example.com/category1" },
    { name: "Category 2", url: "https://example.com/category2" },
    { name: "Category 3", url: "https://example.com/category3" },
    { name: "Category 4", url: "https://example.com/category4" },
  ];
</script>

<div class="container">
  {#each links as link}
    <div class="link-container">
      <a class="link" href={link.url}>{link.name}</a>
    </div>
  {/each}
</div>

<style>
  body {
    margin: 0;
    font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
    background-color: #101820;
    color: #e5e5e5;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  .container {
    display: flex;
    flex-direction: column;
    gap: 15px;
    padding: 20px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
  }
  .link-container {
    position: relative;
    display: inline-block;
    border-radius: 16px;
    overflow: visible;
    --glow-color: 0, 190, 255;
  }
  .link {
    display: inline-block;
    font-size: 1.5rem;
    font-weight: bold;
    padding: 10px 20px;
    color: #4fa3d1;
    border-radius: 8px;
    transition:
      color 0.3s ease,
      text-shadow 0.3s ease,
      transform 0.2s ease;
    text-decoration: none;
    position: relative;
  }
  .link::after {
    content: "";
    display: block;
    width: 0;
    height: 2px;
    background: currentColor;
    transition: width 0.3s ease-in-out;
  }
  .link:hover::after {
    width: 100%;
  }
  .link:hover {
    color: #68c8ff;
    text-shadow: 0 0 8px rgba(104, 200, 255, 0.7);
    transform: scale(1.05);
  }
  .link-container::after {
    content: "";
    position: absolute;
    top: -10%;
    left: -10%;
    width: 120%;
    height: 120%;
    background: radial-gradient(
      circle,
      rgba(var(--glow-color), 0.8) 50%,
      transparent 75%
    );
    border-radius: 16px;
    pointer-events: none;
    opacity: 0;
    filter: blur(8px);
    transition: opacity 0.4s ease;
    z-index: -1;
  }
  .link-container:hover::after {
    opacity: 1;
  }
</style>
