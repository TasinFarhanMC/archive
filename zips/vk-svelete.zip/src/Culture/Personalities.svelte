<script>
  import Footer from "../lib/Footer.svelte";

  const people = [
    {
      name: "Rabindranath Tagore",
      img: "public/rabindranath.webp",
      link: "https://en.wikipedia.org/wiki/Rabindranath_Tagore",
      desc: "Kushtiar bikhato lekhok and asdkjhfdsljfsfdsfh sdfsdflkhdslfhldshflh adlsfjsdjlfdslfdsfldslf",
    },
    {
      name: "Lalon Shah",
      img: "public/lalon.webp",
      link: "https://en.wikipedia.org/wiki/Lalon",
      desc: "Ganj lekhok and asdkjhfdsljfsfdsfh sdfsdflkhdslfhldshflh adlsfjsdjlfdslfdsfldslf",
    },
    {
      name: "Mir Mosharraf Hossain",
      img: "public/mosharraf.webp",
      link: "https://en.wikipedia.org/wiki/Mir_Mosharraf_Hossain",
      desc: "Gand lekhok and asdkjhfdsljfsfdsfh sdfsdflkhdslfhldshflh adlsfjsdjlfdslfdsfldslf",
    },
  ];

  function getAverageRGB(img) {
    const canvas = document.createElement("canvas");
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const context = canvas.getContext("2d");
    context.drawImage(img, 0, 0);
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    let r = 0,
      g = 0,
      b = 0;
    const pixelCount = data.length / 4;

    for (let i = 0; i < data.length; i += 4) {
      r += data[i];
      g += data[i + 1];
      b += data[i + 2];
    }

    return {
      r: Math.round(r / pixelCount),
      g: Math.round(g / pixelCount),
      b: Math.round(b / pixelCount),
    };
  }

  function setGlowColor(event) {
    const img = event.target;
    const container = img.closest(".image-container");
    if (!container) return;
    const { r, g, b } = getAverageRGB(img);
    container.style.setProperty("--glow-color", `${r}, ${g}, ${b}`);
  }
</script>

<header class="bg-blue-600 text-white py-4">
  <div class="container mx-auto px-4 text-center">
    <a href="#/" class="home-button">Home</a>
  </div>
</header>

<main class="container mx-auto px-4 py-8">
  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
    {#each people as person}
      <figure class="bg-gray-900 rounded-lg shadow-md p-4 text-center">
        <a href={person.link} target="_blank" class="image-container">
          <img src={person.img} alt={person.name} on:load={setGlowColor} />
        </a>
        <figcaption class="mt-4">
          <a
            href={person.link}
            target="_blank"
            class="block text-xl font-semibold text-blue-400 hover:text-blue-600"
          >
            {person.name}
          </a>
          <p class="mt-2 text-sm text-gray-300">{person.desc}</p>
        </figcaption>
      </figure>
    {/each}
  </div>
  <div class="text-center mt-8">
    <a
      href="https://www.kushtia.gov.bd/en/site/page/QHBK-%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%96%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A4-%E0%A6%AC%E0%A7%8D%E0%A6%AF%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BF%E0%A6%A4%E0%A7%8D%E0%A6%AC"
      target="_blank"
      class="text-2xl text-blue-400 hover:text-blue-600 hover:underline"
    >
      For More
    </a>
  </div>
</main>

<Footer />
