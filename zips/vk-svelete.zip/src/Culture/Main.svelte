<script lang="ts">
  import BGrid from "../lib/BGrid.svelte";
</script>
