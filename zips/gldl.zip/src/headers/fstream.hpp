#pragma once

#include <fstream>

using IFStream = std::ifstream;
using OFStream = std::ofstream;
