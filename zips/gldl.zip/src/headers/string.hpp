#pragma once
#include <string>

using String = std::string;
using StringView = std::string_view;
