#!/bin/bash

set -e

DIR=$(dirname "$(dirname "$(realpath "$0")")")
cd "$DIR"

if [[ ! -d "$DIR/build" || "$1" ]]; then
  cmake --preset debug
fi

cmake --build --preset debug -- -j "$(nproc)" && ./dist/server
