#include <format>
#include <oatpp/web/client/ApiClient.hpp>
#include <oatpp/web/server/HttpRequestHandler.hpp>

using namespace oatpp;
using namespace oatpp::web::server;

String client_id;
String client_secret;
String refresh_token;
String token;

const String scope = "https://www.googleapis.com/auth/gmail.readonly";
const String token_uri = "https://oauth2.googleapis.com";

String get_token() {
  String b = std::format(
      "grant_type=refresh_token&client_id={}&client_secret={}&refresh_token={}",
      client_id->c_str(), client_secret->c_str(), refresh_token->c_str()
  );
}

/**
async function refreshAccessToken(refreshToken, clientId, clientSecret, tokenUri, scopes =
[]) {
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
  });

  if (scopes.length > 0) {
    body.append("scope", scopes.join(" "));
  }

  try {
    const response = await fetch(tokenUri, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: body.toString(),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("Error Response:", data);
      throw new Error(`${response.status} ${response.statusText} - ${data.error}:
${data.error_description}`);
    }

    return {
      accessToken: data.access_token,
      refreshToken: data.refresh_token || refreshToken, // Use new refresh token if provided
      expiresIn: data.expires_in,
      idToken: data.id_token,
    };
  } catch (error) {
    console.error("Token refresh failed:", error);
    throw error;
  }
}

const tokenUri = "https://oauth2.googleapis.com/token";
const refreshToken =
"1//0gcOydbf3CRi7CgYIARAAGBASNwF-L9Irgh5fwbJsZIf4rkZCb0AXSlYt7dWaJ7MZrBxLwHHYT92YyF7rA5ACOLLAINoEO5cDEG4";
const clientId = "896874297417-eprj6ua5k0dghqa66pvacdm36mqjvdcd.apps.googleusercontent.com";
const clientSecret = "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";
const scopes = ["https://www.googleapis.com/auth/gmail.readonly"];

refreshAccessToken(refreshToken, clientId, clientSecret, tokenUri, scopes)
  .then((tokens) => console.log("New Access Token:", tokens.accessToken))
  .catch((err) => console.error("Error refreshing token:", err));
*/
