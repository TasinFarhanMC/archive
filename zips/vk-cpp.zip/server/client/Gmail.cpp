#include "Gmail.hpp"

#include "oatpp/core/macro/codegen.hpp"
#include "oatpp/web/client/ApiClient.hpp"
#include <iostream>
#include <oatpp-curl/RequestExecutor.hpp>

namespace Api {

Gmail::Gmail(const std::shared_ptr<oatpp::data::mapping::ObjectMapper> &obj_mapper)
    : obj_mapper(obj_mapper) {}

void Gmail::refresh_token() {
  using Headers = oatpp::web::client::ApiClient::Headers;

  // Define the parameters. In a real application these could be members or passed in.
  oatpp::String clientId =
      "896874297417-eprj6ua5k0dghqa66pvacdm36mqjvdcd.apps.googleusercontent.com";
  oatpp::String clientSecret = "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";
  oatpp::String refreshToken =
      "1//"
      "0gcOydbf3CRi7CgYIARAAGBASNwF-"
      "L9Irgh5fwbJsZIf4rkZCb0AXSlYt7dWaJ7MZrBxLwHHYT92YyF7rA5ACOLLAINoEO5cDEG4";

  // Build URL-encoded body string.
  oatpp::String bodyStr = "grant_type=refresh_token"
                          "&client_id=" +
                          clientId + "&client_secret=" + clientSecret +
                          "&refresh_token=" + refreshToken;

  // Optionally add scopes.
  oatpp::String scope = "https://www.googleapis.com/auth/gmail.readonly";
  bodyStr = bodyStr + "&scope=" + scope;

  // Prepare headers.
  Headers headers;
  headers.put("Content-Type", "application/x-www-form-urlencoded");

  // Create the request body.
  auto body = oatpp::web::protocol::http::outgoing::BufferBody::createShared(
      bodyStr, "application/x-www-form-urlencoded"
  );

  std::cout << "Body Data: " << std::endl;
  std::cout << body->getKnownData() << std::endl;

  // Execute the POST request to the token endpoint.
  auto response = con->execute("POST", "/token", headers, body, con->getConnection());

  // Log response status and body.
  std::cout << "Response status: " << response->getStatusCode() << std::endl;
  auto responseBody = response->readBodyToString();
  std::cout << "Response body: " << responseBody->c_str() << std::endl;
}

} // namespace Api
