#pragma once

#include "oatpp/core/Types.hpp"
#include "oatpp/core/macro/codegen.hpp"

namespace DTO {
#include OATPP_CODEGEN_BEGIN(DTO)

class OAuthSec : public oatpp::DTO {
  DTO_INIT(OAuthSec, DTO)

  DTO_FIELD(String, client_id);
  DTO_FIELD(String, client_secret);
  DTO_FIELD(String, refresh_token);
  DTO_FIELD(String, token);
  DTO_FIELD(String, expiry);
};

#include OATPP_CODEGEN_END(DTO)
} // namespace DTO
