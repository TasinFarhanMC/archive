export default async function handleFormSubmit(event: Event) {
  event.preventDefault(); // Prevent default form submission

  const form = event.target as HTMLFormElement;
  const formData = new FormData(form);

  const data: Record<string, unknown> = {};
  formData.forEach((value, key) => {
    data[key] = value;
  });

  try {
    const response = await fetch(form.action, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data), // Correctly formatted data
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const result = await response.json();
    console.log("Server response:", result);
    alert(result.message || "Form submitted successfully!");
  } catch (error) {
    console.error("Error:", error);
    alert("Form submission failed. Please try again.");
  }
}
