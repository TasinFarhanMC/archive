<script lang="ts">
	import submit from '$lib/Form';
</script>

<div class="login">
	<h1>Welcome!</h1>
	<h2>The Virtual World of Kushtia</h2>

	<form action="/api/login" onsubmit={submit}>
		<input type="email" name="email" placeholder="Email" required />
		<input type="password" name="password" placeholder="Password" required />
		<button type="submit">Login</button>
	</form>
</div>
